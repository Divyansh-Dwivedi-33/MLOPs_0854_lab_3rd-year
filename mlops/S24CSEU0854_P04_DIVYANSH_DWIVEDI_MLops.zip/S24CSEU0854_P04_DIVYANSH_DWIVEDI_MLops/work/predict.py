"Predict one delivery, from the command line."

import pandas as pd

from delivery import load_model


def main():
    # Load model from the current directory
    model = load_model("model.joblib")

    order = pd.DataFrame([{
        "distance_km": 7.0,
        "prep_time_min": 25,
        "traffic_level": 3,
        "rain": 0,
    }])

    prediction = model.predict(order)[0]
    print(f"PREDICTION: {prediction:.1f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
